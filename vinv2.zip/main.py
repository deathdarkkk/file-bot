# Import necessary libraries
import os
import sys
import json
import time
import subprocess
import requests
from faker import Faker

def install_package(package):
    try:
        __import__(package)
    except ImportError:
        subprocess.check_call([sys.executable, "-m", "pip", "install", package])

def check_os_and_install():
    packages = ["requests", "faker", "pystyle"]
    for package in packages:
        install_package(package)

check_os_and_install()

from pystyle import Colors, Colorate

os.system('cls' if os.name == 'nt' else 'clear')

def ban():
    print(f''' 
         \033[34m .?77777777777777$.
          \033[34m777..777777777777$+
        \033[34m .77    7777777777$$$
        \033[34m .777 .7777777777$$$$  
        \033[34m .7777777777777$$$$$$                            
        \033[34m ..........:77$$$$$$$
  \033[34m.77777777777777777$$$$$$$$$\033[33m.=======.  
 \033[34m777777777777777777$$$$$$$$$$\033[33m.========  
\033[34m7777777777777777$$$$$$$$$$$$$\033[33m.========= 
\033[34m77777777777777$$$$$$$$$$$$$$$\033[33m.========= 
\033[34m777777777777$$$$$$$$$$$$$$$$ \033[33m:========+.
\033[34m77777777777$$$$$$$$$$$$$$\033[33m+..=========++~
\033[34m777777777$$\033[33m..~=====================+++++
\033[34m77777777$\033[33m~.~~~~=~=================+++++.
\033[34m777777$$$\033[33m.~~~===================+++++++.
\033[34m77777$$$$\033[33m.~~==================++++++++: 
\033[34m7$$$$$$$\033[33m.==================++++++++++. 
 \033[34m.,$$$$$$\033[33m.================++++++++++~.  
         \033[33m.=========~.........           
         \033[33m.=============++++++           
         \033[33m.===========+++..+++           
         \033[33m.==========+++.  .++           
          \033[33m,=======++++++,,++,           
          \033[33m..=====+++++++++=.            
                \033[33m..~+=... \033[39m 
                
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    ''')
ban()

def banner():
    banner_text = ''' 
       ╔╗╔╗╔╗─────╔╗─╔═══╦╗────╔╗─╔╗
       ║║║║║║────╔╝╚╗║╔═╗║║────║║╔╝╚╗
       ║║║║║╠╗╔╦═╩╗╔╝║║─║║║╔╦══╣╚╩╗╔╝
       ║╚╝╚╝║║║║══╣║─║╚═╝║║╠╣╔╗║╔╗║║
       ╚╗╔╗╔╣╚╝╠══║╚╗║╔═╗║╚╣║╚╝║║║║╚╗
       ─╚╝╚╝╚══╩══╩═╝╚╝─╚╩═╩╩═╗╠╝╚╩═╝
       ─────────────────────╔═╝║
       ─────────────────────╚══╝
    '''
    colored_banner = Colorate.Vertical(Colors.red_to_blue, banner_text)
    
    for char in colored_banner:
        print(char, end='', flush=True)
        time.sleep(0.001)  
    print()

banner()

fake = Faker()

class fg:
    BLACK   = '\033[30m'
    RED     = '\033[31m'
    GREEN   = '\033[32m'
    YELLOW  = '\033[33m'
    BLUE    = '\033[34m'
    MAGENTA = '\033[35m'
    CYAN    = '\033[36m'
    WHITE   = '\033[37m'
    RESET   = '\033[39m'

def load_cookies():
    with open('cookies.json', 'r', encoding='utf-8') as f:
        data = json.load(f)
        return data['cookies']

id = input('Enter group id: ')
cookies = load_cookies()
cookie_index = 0

while cookie_index < len(cookies):
    ck = cookies[cookie_index]
    try:
        get = requests.get(f'https://mbasic.facebook.com/privacy/touch/block/confirm/?bid={id}&ret_cancel&source=profile', headers={
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
            'accept-language': 'vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5',
            'cookie': ck,
            'sec-ch-ua': '" Not A;Brand";v="99", "Chromium";v="102", "Google Chrome";v="102"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"Windows"',
            'sec-fetch-dest': 'document',
            'sec-fetch-mode': 'navigate',
            'sec-fetch-site': 'same-origin',
            'sec-fetch-user': '?1',
            'upgrade-insecure-requests': '1'
        }).text
        fb_dtsg = get.split('<input type="hidden" name="fb_dtsg" value="')[1].split('" autocomplete="off" />')[0]
        jazoest = get.split('<input type="hidden" name="jazoest" value="')[1].split('" autocomplete="off" />')[0]
        os.system('clear')
        break
    except:
        print('Cookie dead! Switching to the next cookie...')
        cookie_index += 1

if cookie_index == len(cookies):
    print("All cookies are dead. Exiting...")
    exit()

ban()
banner()

with open('messages.txt', 'r', encoding='utf-8') as file:
    messages = file.readlines()  

delay = float(input("Enter delay (s): "))

os.system("clear")
params = {
    "icm": '1',
}

headers = {
    "Host": "mbasic.facebook.com",
    "content-length": "247",
    "content-type": "application/x-www-form-urlencoded",
    "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.5735.130 Safari/537.36",  
    "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
    "sec-fetch-site": "same-origin",
    "sec-fetch-mode": "navigate",
    "sec-fetch-user": "?1",
    "sec-fetch-dest": "document",
    "accept-encoding": "gzip, deflate, br",
    "accept-language": "vi-VN,vi;q=0.9,en-US;q=0.8,en;q=0.7",
    "cookie": ck,
}

while True:
    for line in messages:  
        nd = line.strip() + "\n"  
        data = f"fb_dtsg={fb_dtsg}&jazoest={jazoest}&body={nd}&send=Send&tids=cid.g.{id}&wwwupp=C3&platform_xmd=&referrer=&ctype=&cver=legacy&csid=366a74a7-2d30-45dd-94c2-ad47d662dcfb"
        rq = requests.post("https://mbasic.facebook.com/messages/send/", params=params, headers=headers, data=data, allow_redirects=False)
        print("Success =>", nd)
        time.sleep(delay)  