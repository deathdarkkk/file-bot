// autoeat.js
const { Item } = require('prismarine-item');

function autoEat(bot) {
  bot.on('health', async () => {
    if (bot.food <= 6) {
      const foodItem = bot.inventory.items().find(item => isFood(item.name));
      if (foodItem) {
        console.log(`Đang ăn: ${foodItem.displayName || foodItem.name}`);
        try {
          await bot.equip(foodItem, 'hand');
          await bot.consume();
          console.log(`Đã ăn ${foodItem.displayName || foodItem.name}`);
        } catch (err) {
          console.log("Lỗi khi ăn:", err);
        }
      } else {
        console.log("Không có đồ ăn trong kho.");
      }
    }
  });
}

function isFood(itemName) {
  const foodList = [
    'apple', 'bread', 'cooked_beef', 'cooked_chicken', 'cooked_porkchop',
    'carrot', 'baked_potato', 'melon', 'mushroom_stew', 'pumpkin_pie'
  ];
  return foodList.includes(itemName);
}

module.exports = autoEat;