const express = require('express');
const http = require('http');
const { Server } = require('socket.io');

function createServer(bot) {
  const app = express();
  const server = http.createServer(app);
  const io = new Server(server);

  app.use(express.static('public'));

  setInterval(() => {
    if (!bot || !bot.entity) return;

    const nearbyEntities = Object.values(bot.entities).map((entity) => ({
      id: entity.id,
      type: entity.type,
      name: entity.username || entity.name || 'Unknown',
      x: entity.position.x - bot.entity.position.x,
      y: entity.position.y - bot.entity.position.y,
      z: entity.position.z - bot.entity.position.z,
    }));

    io.emit('radarUpdate', {
      bot: {
        x: bot.entity.position.x,
        y: bot.entity.position.y,
        z: bot.entity.position.z,
        yaw: bot.entity.yaw,
      },
      entities: nearbyEntities,
    });
  }, 50);

  server.listen(3000, () => {
    console.log('Radar server đang chạy tại http://localhost:3000');
  });

  return server;
}

module.exports = { createServer };