const { pathfinder, Movements, goals } = require('mineflayer-pathfinder');

function goto(bot, x, y, z) {
  if (!bot || !bot.pathfinder) {
    console.error('Bot không hợp lệ hoặc không được khởi tạo.');
    return;
  }

  const movements = new Movements(bot);
  movements.maxClimbHeight = 1;
  movements.canDig = true;
  bot.pathfinder.setMovements(movements);

  const goal = new goals.GoalBlock(x, y, z);

  bot.pathfinder.goto(goal).then(() => {
    console.log(`Bot đã đến tọa độ (${x}, ${y}, ${z})`);
  }).catch((err) => {
    console.error(`Lỗi khi đi đến tọa độ: ${err}`);
  });
}

module.exports = goto;