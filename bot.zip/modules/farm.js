const { Vec3 } = require('vec3');
const { goals } = require('mineflayer-pathfinder');

async function plantSeed(bot, block) {
  const blockAbove = bot.blockAt(new Vec3(block.position.x, block.position.y + 1, block.position.z));
  if (blockAbove.name !== 'air') {
    return;
  }

  const seeds = bot.inventory.items().find(item => 
    item.name.includes('wheat_seeds') || 
    item.name.includes('carrot') || 
    item.name.includes('potato')
  );

  if (!seeds) {
    return;
  }

  try {
    await bot.equip(seeds, 'hand');
    await bot.placeBlock(block, new Vec3(0, 1, 0)); 
  } catch (err) {
    return;
  }
}

async function harvestAndPlant(bot, block) {
  try {
    await bot.dig(block); 
    await collectDrops(bot); 
    await plantSeed(bot, block); 
  } catch (err) {
    return;
  }
}

async function collectDrops(bot) {
  const drops = bot.entities.filter(entity => entity.object && entity.object.name.includes('item'));
  
  for (const drop of drops) {
    try {
      await bot.pathfinder.goto(new goals.GoalBlock(drop.position.x, drop.position.y, drop.position.z));
      await bot.collectBlock(drop.object); 
    } catch (err) {
      return;
    }
  }
}

async function moveToAndHarvest(bot, block) {
  const goal = new goals.GoalNear(block.position.x, block.position.y, block.position.z, 1);
  await bot.pathfinder.goto(goal);
  
  await bot.waitForTicks(10);

  const currentBlock = bot.blockAt(block.position);
  if (currentBlock && 
      ((currentBlock.name === 'wheat' && currentBlock.metadata === 7) ||
      (currentBlock.name === 'carrots' && currentBlock.metadata === 7) ||
      (currentBlock.name === 'potatoes' && currentBlock.metadata === 7))) {
    await harvestAndPlant(bot, currentBlock);
  }
}

async function moveToEmptyFarmland(bot) {
  const farmlandBlocks = bot.findBlocks({
    matching: block => block.name === 'farmland',
    maxDistance: 10,
    count: 10
  });

  for (const farmlandPosition of farmlandBlocks) {
    const farmlandBlock = bot.blockAt(farmlandPosition);
    const blockAbove = bot.blockAt(new Vec3(farmlandPosition.x, farmlandPosition.y + 1, farmlandPosition.z));
    
    if (blockAbove.name === 'air') {
      await plantSeed(bot, farmlandBlock);
      break;
    }
  }
}

async function farm(bot) {
  setInterval(async () => {
    const matureCrops = bot.findBlocks({
      matching: block => {
        return (block.name === 'wheat' && block.metadata === 7) ||  
               (block.name === 'carrots' && block.metadata === 7) || 
               (block.name === 'potatoes' && block.metadata === 7);  
      },
      maxDistance: 10,
      count: 50 
    });

    if (matureCrops.length > 0) {
      for (const cropPosition of matureCrops) {
        const cropBlock = bot.blockAt(cropPosition);
        if (cropBlock) {
          await moveToAndHarvest(bot, cropBlock); 
        }
      }
    }

    await moveToEmptyFarmland(bot);
  }, 2000); 
}

module.exports = farm;