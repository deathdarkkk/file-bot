// spam.js

function spamMessage(bot, message, delay) {
    if (!bot) return;

    const spamInterval = setInterval(() => {
        const randomText = Math.random().toString(36).substring(2, 8); 
        bot.chat(`${message} ${randomText}`);
    }, delay);

    return () => {
        clearInterval(spamInterval);
    };
}

module.exports = spamMessage;