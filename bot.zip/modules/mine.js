// mine.js
const { Vec3 } = require('vec3');
const { goals } = require('mineflayer-pathfinder');

async function equipTool(bot) {
  const pickaxe = bot.inventory.items().find(item => item.name.endsWith('_pickaxe'));
  if (pickaxe) {
    await bot.equip(pickaxe, 'hand');
    console.log("Đã trang bị công cụ:", pickaxe.displayName || pickaxe.name);
  } else {
    console.log("Không tìm thấy công cụ đào trong kho.");
  }
}

async function mineOre(bot, oreBlock) {
  if (!oreBlock) return false;
  await equipTool(bot);
  try {
    const targetPosition = oreBlock.position;
    const goal = new goals.GoalNear(targetPosition.x, targetPosition.y, targetPosition.z, 1);
    await bot.pathfinder.goto(goal);
    const currentBlock = bot.blockAt(targetPosition);
    if (currentBlock && currentBlock.name === oreBlock.name) {
      await bot.dig(currentBlock);
      await collectNearbyItems(bot);
      return true;
    } else {
      console.log("Khối không còn là khoáng sản mục tiêu. Đã thay đổi vị trí.");
      return false;
    }
  } catch (err) {
    console.log("Lỗi khi đào:", err);
    return false;
  }
}

async function collectNearbyItems(bot) {
  const items = bot.nearestEntity(entity => entity.name === 'item' && bot.entity.position.distanceTo(entity.position) < 5);
  if (items) {
    try {
      await bot.pathfinder.goto(new goals.GoalBlock(items.position.x, items.position.y, items.position.z));
      console.log("Đã thu thập vật phẩm:", items.metadata[7].toString());
    } catch (err) {
      console.log("Lỗi khi thu thập vật phẩm:", err);
    }
  }
}

function isOreBlock(block, oreType) {
  return block.name === oreType || block.name === `deepslate_${oreType}`;
}

async function checkAndMineNearbyOres(bot, oreType) {
  const nearbyOre = bot.findBlock({
    matching: block => isOreBlock(block, oreType),
    maxDistance: 128,
    point: bot.entity.position
  });

  if (nearbyOre) {
    console.log("Đã tìm thấy khoáng sản gần:", nearbyOre.name, "tại", nearbyOre.position);
    await mineOre(bot, nearbyOre);
    return true;
  }
  return false;
}

async function findAndMineOres(bot, oreType) {
  for (let y = bot.entity.position.y; y > 5; y--) {
    const oreBlock = bot.findBlock({
      matching: block => isOreBlock(block, oreType),
      maxDistance: 128,
      point: new Vec3(bot.entity.position.x, y, bot.entity.position.z)
    });

    if (oreBlock) {
      console.log("Đã tìm thấy:", oreBlock.name, "tại", oreBlock.position);
      await mineOre(bot, oreBlock);
      return true;
    }
  }
  return false;
}

async function moveAndExplore(bot, oreType) {
  const dx = Math.floor(Math.random() * 16) - 8;
  const dz = Math.floor(Math.random() * 16) - 8;
  const x = bot.entity.position.x + dx * 16;
  const z = bot.entity.position.z + dz * 16;
  const goal = new goals.GoalBlock(x, bot.entity.position.y, z);
  console.log(`Di chuyển đến vị trí mới: (${x}, ${bot.entity.position.y}, ${z})`);

  try {
    await bot.pathfinder.goto(goal);
    await bot.waitForTicks(10);
    await checkAndMineNearbyOres(bot, oreType);
  } catch (err) {
    console.log("Lỗi khi di chuyển:", err);
  }
}

async function exploreAndMine(bot, oreType) {
  while (true) {
    if (await checkAndMineNearbyOres(bot, oreType)) {
      console.log("Đã đào khoáng sản trên đường đi.");
      continue;
    }

    const foundOre = await findAndMineOres(bot, oreType);
    if (!foundOre) {
      await moveAndExplore(bot, oreType);
      await bot.waitForTicks(20);
    } else {
      console.log("Đang tìm khoáng sản ở gần.");
    }

    if (Math.random() < 0.05) {
      await bot.setControlState('jump', true);
      await bot.waitForTicks(10);
      await bot.setControlState('jump', false);
    }
  }
}

module.exports = exploreAndMine;
