const socket = io();
const canvas = document.getElementById('radar');
const ctx = canvas.getContext('2d');
const coordinatesDiv = document.getElementById('bot-coordinates');

canvas.width = window.innerWidth;
canvas.height = window.innerHeight * 0.8;

function drawGrid() {
  const gridSize = 40;
  const cols = Math.ceil(canvas.width / gridSize);
  const rows = Math.ceil(canvas.height / gridSize);

  ctx.strokeStyle = '#555';
  for (let x = 0; x <= canvas.width; x += gridSize) {
    ctx.beginPath();
    ctx.moveTo(x, 0);
    ctx.lineTo(x, canvas.height);
    ctx.stroke();
  }
  for (let y = 0; y <= canvas.height; y += gridSize) {
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.lineTo(canvas.width, y);
    ctx.stroke();
  }
}

function drawRadar(bot, entities) {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  drawGrid();

  const centerX = canvas.width / 2;
  const centerY = canvas.height / 2;

  const yaw = bot.yaw || 0;
  const cosYaw = Math.cos(-yaw);
  const sinYaw = Math.sin(-yaw);

  ctx.fillStyle = '#85bb65';
  ctx.beginPath();
  ctx.arc(centerX, centerY, 8, 0, Math.PI * 2);
  ctx.fill();

  entities.forEach((entity) => {
    let relX = entity.x;
    let relZ = entity.z;

    const rotatedX = relX * cosYaw - relZ * sinYaw;
    const rotatedZ = relX * sinYaw + relZ * cosYaw;

    const x = centerX + rotatedX * 5;
    const y = centerY + rotatedZ * 5;

    ctx.fillStyle = entity.type === 'player' ? '#ff5555' : '#55ff55';
    ctx.beginPath();
    ctx.arc(x, y, 10, 0, Math.PI * 2);
    ctx.fill();

    if (entity.name) {
      ctx.fillStyle = '#ffffff';
      ctx.font = '18px Minecraft';
      ctx.fillText(entity.name, x - 20, y - 20);
    }
  });
}

socket.on('radarUpdate', (data) => {
  drawRadar(data.bot, data.entities);
  coordinatesDiv.textContent = `Tọa độ Bot: X: ${data.bot.x.toFixed(2)} | Y: ${data.bot.y.toFixed(2)} | Z: ${data.bot.z.toFixed(2)}`;
});

window.addEventListener('resize', () => {
  canvas.width = window.innerWidth;
  canvas.height = window.innerHeight * 0.8;
});