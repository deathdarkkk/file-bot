const mineflayer = require('mineflayer');
const { pathfinder } = require('mineflayer-pathfinder');
const moment = require('moment-timezone');
const readline = require('readline');
const fs = require('fs');
const goto = require('./modules/goto');
const mine = require('./modules/mine');
const autoEat = require('./modules/autoeat');
const spamMessage = require('./modules/spam');
const farm = require('./modules/farm');
const { createServer } = require('./modules/radar');

let config;
try {
  const configData = fs.readFileSync('config.json');
  config = JSON.parse(configData);
} catch (error) {
  console.error('Lỗi khi đọc config.json:', error);
  process.exit(1);
}

function getVietnamTime() {
  return moment().tz(config.timez).format('HH:mm:ss');
}

if (process.argv.length < 3) {
  console.log('Usage: npm start <ip:port>');
  process.exit(1);
}

const [host, portString] = process.argv[2].split(':');
const port = portString ? parseInt(portString) : 25565;

if (!host || isNaN(port)) {
  console.log('Địa chỉ không hợp lệ. Vui lòng nhập theo định dạng <ip:port>.');
  process.exit(1);
}

const bot = mineflayer.createBot({
  host: host,
  port: port,
  username: config.username,
  version: config.version
});

bot.loadPlugin(pathfinder);

let isBusy = false;
let spamActive = false;

bot.on('login', () => {
  console.log(`𝐁𝐨𝐭 𝐬𝐮𝐜𝐜𝐞𝐬𝐬𝐮𝐥𝐥𝐲 𝐣𝐨𝐢𝐧𝐞𝐝 𝐭𝐡𝐞 𝐬𝐞𝐫𝐯𝐞𝐫 ${host}:${port}`);
  console.log(`𝐔𝐬𝐞𝐫𝐧𝐚𝐦𝐞: ${config.username}`);
  console.log(`𝐕𝐞𝐫𝐬𝐢𝐨𝐧: ${config.version}`);
  autoEat(bot);
});

bot.on('message', (message) => {
  const parsedMessage = message.toAnsi();
  const regex = /<(.+?)> (.+)/;
  const match = parsedMessage.match(regex);

  if (match) {
    const username = match[1];
    const userMessage = match[2];
    console.log(`[${getVietnamTime()}] [Server Chat/INFO]: ${username}: ${userMessage}`);
  } else {
    console.log(parsedMessage);
  }
});

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

const radarServer = createServer(bot);

rl.on('line', (input) => {
  if (input.startsWith('./goto ')) {
    if (isBusy) {
      console.log('Bot đang bận. Vui lòng đợi.');
      return;
    }

    const coords = input.split(' ').slice(1).map(Number);
    if (coords.length === 3 && coords.every(coord => !isNaN(coord))) {
      const [x, y, z] = coords;
      isBusy = true;
      goto(bot, x, y, z, () => {
        isBusy = false;
      });
    } else {
      console.log('Vui lòng nhập tọa độ hợp lệ: ./goto <x> <y> <z>');
    }
  } else if (input.startsWith('./mine ')) {
    if (isBusy) {
      console.log('Bot đang bận. Vui lòng đợi.');
      return;
    }

    const oreType = input.split(' ')[1];
    if (!oreType) {
      console.log('Vui lòng nhập loại khoáng sản: ./mine <oreType>');
      return;
    }

    isBusy = true;
    mine(bot, oreType, () => {
      isBusy = false;
    });
  } else if (input.startsWith('./spam ')) {
    if (config.spam) {
      if (spamActive) {
        console.log('Bot đã đang spam. Dừng spam bằng cách nhập ./stopspam.');
        return;
      }

      const messageToSpam = input.split(' ').slice(1).join(' ');
      if (!messageToSpam) {
        console.log('Vui lòng nhập nội dung để spam: ./spam <nội dung>');
        return;
      }

      spamActive = spamMessage(bot, messageToSpam, config.spamDelay);
      console.log(`Bot đang spam: "${messageToSpam}" mỗi ${config.spamDelay}ms`);
    } else {
      console.log('Chức năng spam đang bị tắt trong config.json.');
    }
  } else if (input === './stopspam') {
    if (spamActive) {
      spamActive();
      spamActive = false;
      console.log('Bot đã dừng spam.');
    } else {
      console.log('Bot không đang spam.');
    }
  } else if (input === './stop') {
    if (isBusy) {
      console.log('Bot sẽ dừng hành động hiện tại.');
      
      bot.pathfinder.stop();
      bot.digging = false;
      bot.swinging = false;
      bot.collecting = false;
      spamActive = false;

      isBusy = false;
    } else {
      console.log('Bot không đang bận với bất kỳ hành động nào.');
    }
  } else if (input === './farm') {
    if (isBusy) {
      console.log('Bot đang bận. Vui lòng đợi.');
      return;
    }

    console.log('Bot bắt đầu làm ruộng...');
    isBusy = true;
    farm(bot);
    isBusy = false;
  } else if (input === './inventory') {
    const inventoryItems = bot.inventory.items();
    if (inventoryItems.length === 0) {
      console.log('Kho đồ của bot hiện đang trống.');
    } else {
      console.log('𝐈𝐧𝐯𝐞𝐧𝐭𝐨𝐫𝐲:');
      inventoryItems.forEach(item => {
        console.log(`- ${item.displayName} x${item.count}`);
      });
    }
  } else if (input === './list') {
    const playerNames = Object.keys(bot.players);
    if (playerNames.length === 0) {
      console.log('Không có người chơi nào trên server.');
    } else {
      console.log('Danh sách người chơi:');
      playerNames.forEach(player => {
        console.log(`- ${player}`);
      });
    }
   
  } else if (input === ':exit') {
    console.log('𝐄𝐱𝐢𝐭 𝐁𝐨𝐭');
    bot.quit();
  } else {
    bot.chat(input);
  }
});

bot.on('kicked', (reason, loggedIn) => {
  console.log('𝐔𝐧𝐚𝐛𝐥𝐞 𝐭𝐨 𝐜𝐨𝐧𝐧𝐞𝐜𝐭 𝐭𝐨 𝐬𝐞𝐫𝐯𝐞𝐫. 𝐑𝐞𝐚𝐬𝐨𝐧:', reason);
});

bot.on('error', (err) => console.log(`Lỗi: ${err}`));
bot.on('end', () => {
  console.log('𝐁𝐨𝐭 𝐝𝐢𝐬𝐜𝐨𝐧𝐧𝐞𝐜𝐭𝐞𝐝.');
  rl.close();
});
